using System.Threading.Tasks;

namespace $safeprojectname$.Mvvm
{
    public interface INavigable
    {
        Task Activated(NavigationType navType);

        Task Deactivated();
    }
}

