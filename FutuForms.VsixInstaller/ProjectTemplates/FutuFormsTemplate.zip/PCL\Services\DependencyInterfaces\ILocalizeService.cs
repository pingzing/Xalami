using System.Globalization;

namespace $safeprojectname$.Services.DependencyInterfaces
{
    public interface ILocalizeService
    {
        CultureInfo GetCurrentCultureInfo();
    }
}

