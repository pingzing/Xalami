namespace $safeprojectname$.Mvvm
{
    public enum NavigationType
    {
        Forward,
        Back
    }
}

