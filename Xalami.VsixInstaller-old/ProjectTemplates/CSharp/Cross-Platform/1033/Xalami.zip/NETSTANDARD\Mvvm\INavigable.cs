using System.Threading.Tasks;

namespace $ext_safeprojectname$.Mvvm
{
    public interface INavigable
    {
        Task Activated(NavigationType navType);

        Task Deactivated();
    }
}

