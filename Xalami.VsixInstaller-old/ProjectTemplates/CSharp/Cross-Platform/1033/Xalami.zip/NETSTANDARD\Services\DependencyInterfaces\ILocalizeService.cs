using System.Globalization;

namespace $ext_safeprojectname$.Services.DependencyInterfaces
{
    public interface ILocalizeService
    {
        CultureInfo GetCurrentCultureInfo();
    }
}

