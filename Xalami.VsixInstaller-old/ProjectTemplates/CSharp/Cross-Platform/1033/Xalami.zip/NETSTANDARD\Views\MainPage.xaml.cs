using $ext_safeprojectname$.ViewModels;
using Microsoft.Practices.ServiceLocation;
using Xamarin.Forms;

namespace $ext_safeprojectname$.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            this.BindingContext = ServiceLocator.Current.GetInstance<MainViewModel>();
            InitializeComponent();
        }
    }
}

