namespace $ext_safeprojectname$.Mvvm
{
    public enum NavigationType
    {
        Forward,
        Back
    }
}

