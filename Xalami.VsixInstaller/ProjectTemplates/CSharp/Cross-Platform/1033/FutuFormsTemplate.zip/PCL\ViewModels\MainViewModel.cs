using $ext_safeprojectname$.Mvvm;
using $ext_safeprojectname$.Services;

namespace $ext_safeprojectname$.ViewModels
{
    public class MainViewModel : NavigableViewModelBase
    {
        public MainViewModel(INavigationService navService) : base(navService)
        {
            //Add any other services as constructor arguments and cache them locally here.
        }
    }
}

