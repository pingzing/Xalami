namespace $ext_safeprojectname$.Styles
{
    public class FixedStyleKeys
    {
        public static string FixedBodyStyleKey => "FixedBodyStyle";
        public static string FixedCaptionStyleKey => "FixedCaptionStyle";
        public static string FixedListItemTextKey => "FixedListItemTextStyle";
        public static string FixedListItemDetailTextKey => "FixedListItemDetailTextStyle";
    }
}

